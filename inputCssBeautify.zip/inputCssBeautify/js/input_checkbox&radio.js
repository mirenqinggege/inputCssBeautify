(function($){
    $(".check-radio-box").on("click","label",function(){
        let radio = $(this).children("input[type=radio]");
        let selector = radio.attr("name");
        $("input[name=" + selector + "]").each(function(i, o){
            $(o).parent("label").toggleClass("checked",o.checked);
        });
    });

    $(".check-checkbox-box").on("click","label",function () {
        let next = $(this).children("input[type=checkbox]");
        let checked = next[0].checked;
        $(this).toggleClass("checked",checked);
    });
})(jQuery);